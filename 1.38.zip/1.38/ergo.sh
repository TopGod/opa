#!/bin/bash

#################################
## Begin of user-editable part ##
#################################

POOL=de.ergo.herominers.com:1180
WALLET=9hzaPGCxQwz1WFpGqQk5KBYHoTEvBHionoP8HZYJmJdYFip3fAD

#################################
##  End of user-editable part  ##
#################################

cd "$(dirname "$0")"

./lol --algo AUTOLYKOS2 --pool $POOL --user $WALLET $@
while [ $? -eq 42 ]; do
    sleep 10s
    ./lol --algo AUTOLYKOS2 --pool $POOL --user $WALLET $@
done
