#!/bin/bash

#################################
## Begin of user-editable part ##
#################################

POOL=eth.2miners.com:2020
WALLET=nano_3s5se6p81j4isxsf11dgmtszeqpnasrdimz79nqswhberiegfg5jd89a5idx

#################################
##  End of user-editable part  ##
#################################

cd "$(dirname "$0")"

./lol --algo ETHASH --pool $POOL --user $WALLET $@
while [ $? -eq 42 ]; do
    sleep 10s
    ./lol --algo ETHASH --pool $POOL --user $WALLET $@
done
