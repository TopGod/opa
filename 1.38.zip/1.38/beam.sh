#!/bin/bash

#################################
## Begin of user-editable part ##
#################################

POOL=beam-eu.leafpool.com:3333
WALLET=348a9ebf260afc7eb48f2b6e0bf980bf75317de0cbca84c15d15bb98ebd9d0186c3

#################################
##  End of user-editable part  ##
#################################

cd "$(dirname "$0")"

./lol --coin BEAM --pool $POOL --user $WALLET $@
